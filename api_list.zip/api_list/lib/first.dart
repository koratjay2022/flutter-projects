import 'dart:convert';

import 'package:api_list/user.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

class first extends StatefulWidget {
  const first({Key? key}) : super(key: key);

  @override
  State<first> createState() => _firstState();
}

class _firstState extends State<first> {
  List l = [];
  List<int> i=[0,1,2,3,4,5,6,7,8,9];

  Future get() async {
    var url = Uri.https('jsonplaceholder.typicode.com', 'users');
    var response = await http.get(url);
    l = jsonDecode(response.body);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(),
      body: FutureBuilder(
        future: get(),
        builder: (context, snapshot) {
          if(snapshot.connectionState==ConnectionState.done){
                    return ListView.builder(itemCount: i.length,itemBuilder: (context, index) {
                      var x=user.fromJson(l[index]);
                      return ExpansionTile(
                        title: Text("${x.name}"),
                        subtitle: Text("${x.email}"),
                        leading: Text("${x.id}"),
                        children: [
                          ExpansionTile(
                            title: Text("geo"),
                            subtitle: Text("${x.address!.suite} / ${x.address!.city} / ${x.address!.zipcode}"),
                            children: [
                              ListTile(
                                title: Text("${x.address!.geo!.lat}"),
                                subtitle: Text("${x.address!.geo!.lng}"),
                              ),
                            ],
                          ),
                        ],
                      );
                    },
                      shrinkWrap: true,
                    );
                  } else {
            return Center(child: CircularProgressIndicator(),);
          }
        },
      ),
    );
  }
}


