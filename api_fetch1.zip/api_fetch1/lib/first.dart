import 'dart:convert';

import 'package:api_fetch1/user.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

class first extends StatefulWidget {
  const first({Key? key}) : super(key: key);

  @override
  State<first> createState() => _firstState();
}

class _firstState extends State<first> {


  @override
  void initState() {
    super.initState();

    get();
  }
  user? u;
  get() async {
    var url = Uri.https('reqres.in', 'api/unknown');
    var response = await http.get(url);

    print('Response status: ${response.statusCode}');
    print('Response body: ${response.body}');
    Map<String, dynamic> m = jsonDecode(response.body);
    u=user.fromJson(m);

    setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(""),),
      body: Column(
        children: [
          Text("${u!.page}"),
          Text("${u!.perPage}"),
          Text("${u!.total}"),
          Text("${u!.totalPages}"),
          Expanded(
            child: ListView.builder(itemCount: u!.data!.length,itemBuilder: (context, index) {
              return ListTile(
                leading: Text("${u!.data![index].id}"),
                title: Text("${u!.data![index].name}"),
                subtitle: Text("${u!.data![index].color}"),
              );
            },
            shrinkWrap: true,
            ),
          )
        ],
      ),
    );
  }
}
