import 'package:api_fetch1/first.dart';
import 'package:flutter/material.dart';

void main(){
  runApp(MaterialApp(home: first(),));
}



