package com.example.api_fetch1;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
