import 'package:flutter/material.dart';
import 'package:notes/first.dart';

class image extends StatefulWidget {
  const image({Key? key}) : super(key: key);

  @override
  State<image> createState() => _imageState();
}

class _imageState extends State<image> {
  List<String> ima= [
    "1.jpg","2.jpg","3.jpg","4.jpg","5.jpg"
  ];
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("image"),
      ),
      body: GridView.builder(itemCount: ima.length,
          itemBuilder:(context, index) {
        return InkWell(
          onTap: () {
          },
          child: Container(
            height: 100,
            width: 200,
            decoration: BoxDecoration(
              image: DecorationImage(image: AssetImage("img/${ima[index]}"))
            ),
          ),
        );
      },gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 2)),
    );
  }
}
