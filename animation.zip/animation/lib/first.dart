import 'package:animation/second.dart';
import 'package:animations/animations.dart';
import 'package:flutter/material.dart';

class first extends StatefulWidget {
  const first({Key? key}) : super(key: key);

  @override
  State<first> createState() => _firstState();
}

class _firstState extends State<first> {
  bool anim = false;


  @override
  void initState() {
    Future.delayed(Duration(milliseconds: 30));
    setState(() {
      anim=!anim;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("first page"),
      ),
      body: Center(
        child: OpenContainer(
          transitionDuration: Duration(seconds: 2),
          openBuilder:(context, action) {
          return second();
        },closedBuilder: (context, action) {
          return Container(
            height: anim?200:100,
            width: anim?200:100,
            decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(40),
                gradient: LinearGradient(colors: anim?[Colors.red,Colors.yellow,Colors.blue]:[Colors.green,Colors.cyan,Colors.deepPurple])
            ),
            alignment: anim?Alignment.centerLeft:Alignment.centerRight,
          );
        }, ),
      ),
    );
  }
}
