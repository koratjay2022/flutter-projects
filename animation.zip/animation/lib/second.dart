import 'package:flutter/material.dart';

class second extends StatefulWidget {
  const second({Key? key}) : super(key: key);

  @override
  State<second> createState() => _secondState();
}

class _secondState extends State<second> {
  bool anim = false;

  @override
  void initState() {
    super.initState();
    Future.delayed(Duration(microseconds: 100)).then((value) {
      setState(() {
        anim = !anim;
        print(anim);
      });
    });

  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(),
      body: Column(
        children: [
          AnimatedContainer(
            onEnd: () {
              setState(() {
                anim = !anim;
                print("hello = $anim");
              });
            },
            duration: Duration(seconds: 2),
            height: anim ? 200 : 100,
            width: anim ? 200 : 100,
            decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(40),
                gradient: LinearGradient(
                    colors: anim
                        ? [Colors.red, Colors.yellow, Colors.blue]
                        : [Colors.green, Colors.cyan, Colors.deepPurple]
                )
            ),
            alignment: anim ? Alignment.centerLeft : Alignment.centerRight,
          ),
        ],
      ),
    );
  }
}
